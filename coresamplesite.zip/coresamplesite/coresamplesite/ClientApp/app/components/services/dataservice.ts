﻿import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs'

@Injectable()
export class DataService {

    constructor(
        private http: Http
    ) { }

    public getData(url: string) {
        return this.http.get(url);
    }
    public getResult(url: string) {
        return this.http.get(url)
            .map((res: any) => res.json());
    }
}