﻿export interface Country {
    countryId: number;
    countryName: string;
    formalName: string;
    isoAlpha3Code: string;
    isoNumericCode: number;
    countryType: string;
    latestRecordedPopulation: number;
    continent: string;
    region: string;
    subregion: string;
    lastEditedBy: number;
    validFrom: Date;
    validTo: Date;
    lastEditedByNavigation?: any;
    stateProvinces: any[];
}
