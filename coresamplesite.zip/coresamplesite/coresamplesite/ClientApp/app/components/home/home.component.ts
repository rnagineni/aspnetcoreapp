import { Component, Inject } from '@angular/core';

import { Http } from '@angular/http';
import { Observable } from 'rxjs'

import { DataService } from '../services/dataservice'
import { Country } from '../models/country'

@Component({
    selector: 'home',
    templateUrl: './home.component.html'
})
export class HomeComponent {
    public countries: Country[];
    constructor(http: Http, @Inject('BASE_URL') baseUrl: string) {

        var url = baseUrl + 'api/Countries';
        var ts = new DataService(http).getResult(url).subscribe(result => {
            this.countries = result as Country[];
            console.log(this.countries);
        }, error => console.error(error));
    }
}
